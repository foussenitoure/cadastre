create function st_length2d_spheroid(geometry, spheroid) returns double precision
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public._postgis_deprecate('ST_Length2D_Spheroid', 'ST_Length2DSpheroid', '2.2.0');
    SELECT public.ST_Length2DSpheroid($1,$2);
$$;

comment on function st_length2d_spheroid(geometry, spheroid) is 'args: a_geometry, a_spheroid - Calculates the 2D length/perimeter of a geometry on an ellipsoid. This is useful if the coordinates of the geometry are in longitude/latitude and a length is desired without reprojection.';

alter function st_length2d_spheroid(geometry, spheroid) owner to toure;


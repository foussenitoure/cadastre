create function st_translate(geometry, double precision, double precision) returns geometry
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public.ST_Translate($1, $2, $3, 0)
$$;

comment on function st_translate(geometry, double precision, double precision) is 'args: g1, deltax, deltay - Translate a geometry by given offsets.';

alter function st_translate(geometry, double precision, double precision) owner to toure;


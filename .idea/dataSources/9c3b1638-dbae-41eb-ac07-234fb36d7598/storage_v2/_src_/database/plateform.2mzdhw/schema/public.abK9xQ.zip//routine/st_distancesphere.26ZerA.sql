create function st_distancesphere(geom1 geometry, geom2 geometry) returns double precision
  immutable
  strict
  parallel safe
  cost 300
  language sql
as
$$
select public.ST_distance( public.geography($1), public.geography($2),false)

$$;

comment on function st_distancesphere(geometry, geometry) is 'args: geomlonlatA, geomlonlatB - Returns minimum distance in meters between two lon/lat geometries. Uses a spherical earth and radius derived from the spheroid defined by the SRID. Faster than ST_DistanceSpheroid , but less accurate. PostGIS versions prior to 1.5 only implemented for points.';

alter function st_distancesphere(geometry, geometry) owner to toure;


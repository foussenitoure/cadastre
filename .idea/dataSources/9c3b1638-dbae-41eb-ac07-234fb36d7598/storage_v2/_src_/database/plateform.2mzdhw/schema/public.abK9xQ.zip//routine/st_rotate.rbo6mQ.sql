create function st_rotate(geometry, double precision, geometry) returns geometry
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public.ST_Affine($1,  cos($2), -sin($2), 0,  sin($2),  cos($2), 0, 0, 0, 1, public.ST_X($3) - cos($2) * public.ST_X($3) + sin($2) * public.ST_Y($3), public.ST_Y($3) - sin($2) * public.ST_X($3) - cos($2) * public.ST_Y($3), 0)
$$;

comment on function st_rotate(geometry, double precision, geometry) is 'args: geomA, rotRadians, pointOrigin - Rotate a geometry rotRadians counter-clockwise about an origin.';

alter function st_rotate(geometry, double precision, geometry) owner to toure;


create function st_transform(rast raster, srid integer, scalex double precision, scaley double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125) returns raster
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public._ST_gdalwarp($1, $5, $6, $2, $3, $4)
$$;

comment on function st_transform(raster, integer, double precision, double precision, text, double precision) is 'args: rast, srid, scalex, scaley, algorithm=NearestNeighbor, maxerr=0.125 - Reprojects a raster in a known spatial reference system to another known spatial reference system using specified resampling algorithm. Options are NearestNeighbor, Bilinear, Cubic, CubicSpline, Lanczos defaulting to NearestNeighbor.';

alter function st_transform(raster, integer, double precision, double precision, text, double precision) owner to toure;


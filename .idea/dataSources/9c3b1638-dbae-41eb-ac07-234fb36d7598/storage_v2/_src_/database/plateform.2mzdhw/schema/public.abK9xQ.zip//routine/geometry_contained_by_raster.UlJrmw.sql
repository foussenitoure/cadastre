create function geometry_contained_by_raster(geometry, raster) returns boolean
  immutable
  strict
  parallel safe
  language sql
as
$$
select $1 OPERATOR(public.@) $2::public.geometry
$$;

alter function geometry_contained_by_raster(geometry, raster) owner to toure;


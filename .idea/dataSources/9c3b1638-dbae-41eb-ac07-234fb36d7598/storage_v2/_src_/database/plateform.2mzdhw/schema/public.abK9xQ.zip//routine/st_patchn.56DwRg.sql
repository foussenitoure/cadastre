create function st_patchn(geometry, integer) returns geometry
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT CASE WHEN public.ST_GeometryType($1) = 'ST_PolyhedralSurface'
	THEN public.ST_GeometryN($1, $2)
	ELSE NULL END

$$;

comment on function st_patchn(geometry, integer) is 'args: geomA, n - Return the 1-based Nth geometry (face) if the geometry is a POLYHEDRALSURFACE, POLYHEDRALSURFACEM. Otherwise, return NULL.';

alter function st_patchn(geometry, integer) owner to toure;


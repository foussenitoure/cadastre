create function st_mapalgebrafct(rast raster, onerastuserfunc regprocedure, VARIADIC args text[]) returns raster
  immutable
  parallel safe
  language sql
as
$$
SELECT public.ST_mapalgebrafct($1, 1, NULL, $2, VARIADIC $3)
$$;

alter function st_mapalgebrafct(raster, regprocedure, text[]) owner to toure;


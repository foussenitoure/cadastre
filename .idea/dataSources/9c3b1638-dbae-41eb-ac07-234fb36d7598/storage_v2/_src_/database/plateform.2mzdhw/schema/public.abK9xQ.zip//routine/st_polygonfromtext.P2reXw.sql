create function st_polygonfromtext(text) returns geometry
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public.ST_PolyFromText($1)
$$;

comment on function st_polygonfromtext(text) is 'args: WKT - Makes a Geometry from WKT with the given SRID. If SRID is not given, it defaults to 0.';

alter function st_polygonfromtext(text) owner to toure;

